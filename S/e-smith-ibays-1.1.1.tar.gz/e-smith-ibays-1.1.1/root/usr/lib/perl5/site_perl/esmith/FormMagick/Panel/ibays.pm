#!/usr/bin/perl -w 

#
# $Id: ibays.pm,v 1.2 2003/09/09 19:12:01 apc Exp $
#

package    esmith::FormMagick::Panel::ibays;

use strict;

use esmith::FormMagick;
use esmith::AccountsDB;
use esmith::ConfigDB;
use esmith::DomainsDB;
use esmith::cgi;
use esmith::util;
use File::Basename;
use Exporter;
use Carp;
use esmith::IbayPlugin;

our @ISA = qw(esmith::FormMagick Exporter);

our @EXPORT = qw(
    print_ibay_table
    print_ibay_name_field
    print_vhost_message
    group_list
    userAccess_list
    publicAccess_list
    ibayPlugin_list
    ibay_plugin_load_fields
    create_modify_post_event
    max_ibay_name_length
    handle_ibays
    remove_ibay
    reset_password
    getExtraParams
    verifyPasswords
    check_password
    print_save_or_add_button
    wherenext
);

our $VERSION = sprintf '%d.%03d', q$Revision: 1.2 $ =~ /: (\d+).(\d+)/;

our $accountdb = esmith::AccountsDB->open();
our $configdb = esmith::ConfigDB->open();

=pod 

=head1 NAME

esmith::FormMagick::Panels::ibays - useful panel functions 

=head1 SYNOPSIS

    use esmith::FormMagick::Panels::ibays;

    my $panel = esmith::FormMagick::Panel::ibays->new();
    $panel->display();

=head1 DESCRIPTION

=head2 new();

Exactly as for esmith::FormMagick

=begin testing

$ENV{ESMITH_ACCOUNT_DB} = "10e-smith-base/accounts.conf";
$ENV{ESMITH_CONFIG_DB} = "10e-smith-base/configuration.conf";
$ENV{ESMITH_DOMAINS_DB} = "10e-smith-base/domains.conf";

use_ok('esmith::FormMagick::Panel::ibays');
use vars qw($panel);
ok($panel = esmith::FormMagick::Panel::ibays->new(), 
    "Create panel object");
isa_ok($panel, 'esmith::FormMagick::Panel::ibays');

{ package esmith::FormMagick::Panel::ibays;
  our $accountdb;
  ::isa_ok($accountdb, 'esmith::AccountsDB');
}

=end testing

=cut

sub new 
{
    shift;
    my $self = esmith::FormMagick->new();
    $self->{calling_package} = (caller)[0];
    $self->{defaultMaxLength} = 12;
    bless $self;
    return $self;
}

=head1 HTML GENERATION ROUTINES

Routines for generating chunks of HTML needed by the panel.

=head1 ROUTINES FOR FILLING IN FIELDS

=head2 print_ibay_table

Prints out the ibay table on the front page.

=for testing
my $self = esmith::FormMagick::Panel::ibays->new();
$self->{cgi} = CGI->new("");
can_ok('main', 'print_ibay_table');
$self->print_ibay_table();
like($_STDOUT_, qr/NAME/, "Found NAME header in table output");
#like($_STDOUT_, qr/testibay/, "Found test ibay in user table output");
#like($_STDOUT_, qr/ff0000/, "Found red 'reset password' output");

=cut

sub print_ibay_table {
    my $self = shift;
    my $q = $self->{cgi};
    my $name        = $self->localise('NAME');
    my $description = $self->localise('DESCRIPTION');
    my $plugin      = $self->localise('PLUGIN');
    my $modify      = $self->localise('MODIFY');
    my $remove      = $self->localise('REMOVE');
    my $resetpw     = $self->localise('RESET_PASSWORD');
    my $action_h    = $self->localise('ACTION');
    my @ibays = $accountdb->ibays();

    unless ( scalar @ibays )
    {
        print $q->Tr($q->td($self->localise('NO_IBAYS')));
        return "";
    }

    print $q->start_table({-CLASS => "sme-border"}),"\n";
    print $q->Tr (
                  esmith::cgi::genSmallCell($q, $name,"header"),
                  esmith::cgi::genSmallCell($q, $description,"header"),
                  esmith::cgi::genSmallCell($q, $plugin, "header"),
                  esmith::cgi::genSmallCell($q, $action_h,"header", 3)),"\n";
    my $scriptname = basename($0);

    foreach my $i (@ibays) {
        my $ibayname = $i->key();
        my $ibaydesc = $i->prop('Name');
	my $ibayPlugin = $i->prop('Plugin') || '&nbsp;';
	my $modifiable = $i->prop('Modifiable') || 'yes';
	my $passwordable = $i->prop('Passwordable') || 'yes';
	my $removable = $i->prop('Removable') || 'yes';
	my $needPassword = grep { $_ eq $i->prop('PublicAccess') } 
				qw(local-pw global-pw global-pw-remote);

        my $params = $self->build_ibay_cgi_params($ibayname, $i->props());


	my $href = "$scriptname?$params&action=modify&wherenext=";

        my $actionModify = '&nbsp;';
	if ($modifiable eq 'yes')
	{
	    $actionModify .= $q->a({href => "${href}CreateModify"}, $modify) 
			  . '&nbsp;';
	}

	my $actionResetPw = '&nbsp;';
	if ($passwordable eq 'yes')
	{
	    if ($i->prop('PasswordSet') ne 'yes' && $needPassword)
	    {
		$actionResetPw  .= $q->a({href => "${href}Password", 
				    class => "error"}, $resetpw) 
	    }
	    else
	    {
		$actionResetPw  .= $q->a({href => "${href}Password"}, $resetpw) 
	    }
	    $actionResetPw .= '&nbsp';
	}

	my $actionRemove = '&nbsp;';
	if ($removable eq 'yes')
	{
	    $actionRemove .= $q->a({href => "${href}Remove"}, $remove) 
			  . '&nbsp';
	}

	print $q->Tr (
            esmith::cgi::genSmallCell($q, $ibayname,"normal"),
            esmith::cgi::genSmallCell($q, $ibaydesc,"normal"),
            esmith::cgi::genSmallCell($q, $ibayPlugin,"normal"),
            esmith::cgi::genSmallCell($q, $actionModify,"normal"),
            esmith::cgi::genSmallCell($q, $actionResetPw,"normal"),
            esmith::cgi::genSmallCell($q, $actionRemove,"normal"));

#                  esmith::cgi::genSmallCell($q, $q->a(
#                      {href => "$scriptname?$params&action=modify&wherenext=CreateModify"},$modify),"normal"),
#                  esmith::cgi::genSmallCell($q, $q->a(
#                      {href => "$scriptname?$params&action=modify&wherenext=Password"},$resetpw),"normal"),
#                  esmith::cgi::genSmallCell($q, $q->a(
#                      {href => "$scriptname?$params&action=modify&wherenext=Remove"},$remove),"normal"));
#        print qq(
#    <tr>
#        <td>$ibayname</td>
#        <td>$ibaydesc</td>
#        <td><a href="$scriptname?$params&action=modify&wherenext=CreateModify">
#            $modify</a></td>
#        <td><a href="$scriptname?$params&wherenext=Password">
#            $fontopen $resetpw... $fontclose</a></td>
#        <td><a href="$scriptname?$params&wherenext=Remove">
#            $remove...</a></td>
#    </tr>
#        );
    }

    print $q->end_table,"\n";

    return "";
}

sub build_ibay_cgi_params {
    my ($self, $ibayname, %oldprops) = @_;

    #$oldprops{'description'} = $oldprops{Name};
    #delete $oldprops{Name};

    my %props = (
        page    => 0,
        page_stack => "",
        #".id"         => $self->{cgi}->param('.id') || "",
        name => $ibayname,
        #%oldprops
    );

    return $self->props_to_query_string(\%props);
}

*wherenext = \&CGI::FormMagick::wherenext;
sub print_ibay_name_field {
    my $self = shift;
    my $in = $self->{cgi}->param('name') || '';
    my $action = $self->{cgi}->param('action') || '';
    my $maxLength = $configdb->get('maxIbayNameLength');
    $maxLength = $maxLength ? $maxLength->value : $self->{defaultMaxLength};
    print qq(<tr><td colspan="2">) . $self->localise('NAME_FIELD_DESC',
	{maxLength => $maxLength}) . qq(</td></tr>);
    print qq(<tr><td class="sme-noborders-label">) . 
	$self->localise('NAME_LABEL') . qq(</td>\n);
    if ($action eq 'modify' and $in) {
        print qq(
            <td class="sme-noborders-content">$in 
            <input type="hidden" name="name" value="$in">
            <input type="hidden" name="action" value="modify">
            </td>
        );

        # Read the values for each field from the accounts db and store
        # them in the cgi object so our form will have the correct 
        # info displayed.
        my $q = $self->{cgi};
        my $rec = $accountdb->get($in);
        if ($rec)
        {
            $q->param(-name=>'description',-value=>
                $rec->prop('Name'));
            $q->param(-name=>'group',-value=>
                $rec->prop('Group'));
            $q->param(-name=>'userAccess',-value=>
                $rec->prop('UserAccess'));
            $q->param(-name=>'publicAccess',-value=>
                $rec->prop('PublicAccess'));
            $q->param(-name=>'CgiBin',-value=>
                $rec->prop('CgiBin'));
	    $q->param(-name=>'Plugin',-value=>
		$rec->prop('Plugin'));
        }
    } else {
        print qq(
            <td><input type="text" name="name" value="$in">
            <input type="hidden" name="action" value="create">
            </td>
        );
    }

    print qq(</tr>\n);
    return undef;

}

=pod

=head2 print_vhost_message()

Prints a warning message that vhosts whose content is this ibay will be
modified to point to primary site.

=for testing
$panel->{cgi} = CGI->new();
$panel->{cgi}->param(-name=>'name', -value=>'bar');
is($panel->print_vhost_message(), undef, 'print_vhost_message');

=cut

sub print_vhost_message {
	my $self = shift;
	my $q = $self->{cgi};
	my $name = $q->param('name');

	my $domaindb = esmith::DomainsDB->open();
	my @domains = $domaindb->get_all_by_prop(Content => $name);
	my $vhostListItems = join "\n",
		(map ($q->li($_->key." ".$_->prop('Description')),
		@domains));
	if ($vhostListItems)
	{
		print $self->localise('VHOST_MESSAGE', {vhostList => $vhostListItems});
	}
	return undef;
}

=head2 group_list()

Returns a hash of groups for the Create/Modify screen's group field's
drop down list.

=for testing
can_ok('main', 'group_list');
my $g = group_list();
is(ref($g), 'HASH', "group_list returns a hashref");
is($g->{simpsons}, "Simpsons Family (simpsons)",
    "Found names and descriptions");

=cut

sub group_list 
{
    my @groups = $accountdb->groups();
    my %groups = ( admin => 'Admin', shared => 'Everyone' );
    foreach my $g (@groups) {
        $groups{$g->key()} = $g->prop('Description')." (".
	    $g->key.")";
    }
    return \%groups;
}

=head2 userAccess_list

Returns the hash of user access settings for showing in the user access
drop down list.

=for testing
can_ok('main', 'userAccess_list');
my $u = userAccess_list();
is(ref($u), 'HASH', "userAccess_list returns a hashref");
like($u->{'wr-group-rd-group'}, qr/WGRG/, "hashref contains the right stuff");

=cut

sub userAccess_list 
{
    return {
        'wr-group-rd-group'    => 'WGRG',
        'wr-group-rd-everyone' => 'WGRE',
        'wr-admin-rd-group'    => 'WARG'
    };
}

=head2 publicAccess_list

Returns the hash of public access settings for showing in the public
access drop down list.

=for testing
can_ok('main', 'publicAccess_list');
my $u = publicAccess_list();
is(ref($u), 'HASH', "publicAccess_list returns a hashref");
is($u->{none}, 'NONE', "hashref contains the right stuff");

=cut

sub publicAccess_list {
    return {
        'none'             => 'NONE',
        'local'            => 'LOCAL_NETWORK_NO_PASSWORD',
        'local-pw'         => 'LOCAL_NETWORK_PASSWORD',
        'global'           => 'ENTIRE_INTERNET_NO_PASSWORD',
        'global-pw'        => 'ENTIRE_INTERNET_PASSWORD',
        'global-pw-remote' => 'ENTIRE_INTERNET_PASSWORD_REMOTE'
    };
}

sub ibayPlugin_list
{
    my @list = ('none', grep {$_ ne 'none'} esmith::IbayPlugin->list);
    return \@list;
}

sub ibay_plugin_load_fields
{
    my $self = shift;
    my $name = $self->cgi->param('name');
    my $pluginName = $self->cgi->param('Plugin');
    my $ibayPlugin = esmith::IbayPlugin->load($pluginName);
    my $acct = $accountdb->get($name);
    $ibayPlugin->ibay_panel_load_fields($self, $acct);

    return undef;
}

=head1 VALIDATION ROUTINES

=head2 max_ibay_name_length()

Checks the length of a given i-bay name against the maximum set in the
maxIbayNameLength record of the configuration database.  Defaults to a
maximum length of $self->{defaultMaxLength} if nothing is set in the config db.

=begin testing

my $conf = esmith::ConfigDB->open();
isa_ok($conf, 'esmith::ConfigDB');
my $max_record = $conf->get('maxIbayNameLength') 
    || $conf->new_record('maxIbayNameLength');
$max_record->set_value(12);
$conf->reload;
is($conf->get('maxIbayNameLength')->value(), 12, "Max ibay length is 12");

can_ok('main', 'max_ibay_name_length');
is($panel->max_ibay_name_length('abc'), 'OK', "Short ibay name is OK");
isnt($panel->max_ibay_name_length('abcdefghiabcdefghi'), 'OK', "Long ibay name is not OK");

$max_record->set_value(2);
$conf->reload();
is($max_record->value(), 2, "Set max length to a very low number");
isnt($panel->max_ibay_name_length('abc'), 'OK', "Short ibay name is no longer OK");

=end testing

=cut

sub max_ibay_name_length {
    my ($self, $data) = @_;
    $configdb->reload();
    my $max;
    if (my $max_record = $configdb->get('maxIbayNameLength')) {
        $max = $max_record->value();
    } else {
        $max = $self->{defaultMaxLength};
    }

    if (length($data) <= $max) {
        return "OK";
    } else {
        return $self->localise("MAX_IBAY_NAME_LENGTH_ERROR",
	    {acctName => $data, 
	    maxIbayNameLength => $max, 
	    maxLength => $max});
    }
}


=pod

=head2 conflict_check

Check the proposed name for clashes with existing pseudonyms or other 
accounts of any type.

=cut
sub conflict_check
{
    my ($self, $name) = @_;
    my $rec = $accountdb->get($name);

    my $type;
    if (defined $rec)
    {
	my $type = $rec->prop('type');
	if ($type eq "pseudonym")
	{
	    my $acct = $rec->prop("Account");
	    my $acct_type = $accountdb->get($acct)->prop('type');

	    return $self->localise('ACCT_CLASHES_WITH_PSEUDONYM',
		{acctName => $name, acctType => $acct_type,
		acct => $acct});
	}
    }
    elsif (defined getpwnam($name) || defined getgrnam($name))
    {
	$type = 'system';
    }
    else
    {
	# No account record and no account
	return 'OK';
    }
    return $self->localise('ACCOUNT_EXISTS',
	    {acctName => $name, acctType => $type});
}

=head1 THE ROUTINES THAT ACTUALLY DO THE WORK

=cut

# called by CGI::FormMagick::new()
sub munge_fm_obj {
    my $self = shift;

    # load in the IbayPlugin
    my $pluginName = $self->cgi->param('Plugin');
    my $ibayPlugin = esmith::IbayPlugin->load($pluginName);
    $ibayPlugin->ibay_panel_load_form_elements($self);
}

sub create_modify_post_event {
    my $self = shift;

    # delegate to the IbayPlugin
    my $pluginName = $self->cgi->param('Plugin');
    my $ibayPlugin = esmith::IbayPlugin->load($pluginName);
    $ibayPlugin->create_modify_post_event($self);
}


=for testing
can_ok('main', 'handle_ibays');

=cut

sub handle_ibays {
    my ($self) = @_;
    
    # delegate to the IbayPlugin
    my $pluginName = $self->cgi->param('Plugin');
    my $ibayPlugin = esmith::IbayPlugin->load($pluginName);
    $self->wherenext($ibayPlugin->handle_ibays_wherenext());

    if ($self->cgi->param("action") eq "create") {
        $self->create_ibay();
    } else {
        $self->modify_ibay();
    }
}

=head2 print_save_or_add_button()
=cut

sub print_save_or_add_button {
    my ($self) = @_;

    if ($self->cgi->param("action") eq "modify") {
        $self->print_button("SAVE");
    } else {
        $self->print_button("ADD");
    }

}

sub create_ibay {
    my ($self) = @_;
    my $name = $self->cgi->param('name');

    my $msg = $self->validate_name($name);
    unless ($msg eq "OK")
    {
        return $self->error($msg);
    }

    $msg = $self->max_ibay_name_length($name);
    unless ($msg eq "OK")
    {
        return $self->error($msg);
    }

    $msg = $self->conflict_check($name);
    unless ($msg eq "OK")
    {
        return $self->error($msg);
    }

    my $uid  = $accountdb->get_next_uid();
    if (my $acct = $accountdb->new_record($name, {
            Name         => $self->cgi->param('description'),
            CgiBin       => $self->cgi->param('CgiBin'),
            Group        => $self->cgi->param('group'),
            PublicAccess => $self->cgi->param('publicAccess'),
            UserAccess   => $self->cgi->param('userAccess'),
	    Plugin       => $self->cgi->param('Plugin'),
            Uid          => $uid,
            Gid          => $uid,
            PasswordSet  => 'no',
            type         => 'ibay',
        }) ) {

	# delegate to the IbayPlugin
	my $pluginName = $self->cgi->param('Plugin');
	my $ibayPlugin = esmith::IbayPlugin->load($pluginName);
	$ibayPlugin->ibay_panel_save_fields($self, $acct);

        if (system ("/sbin/e-smith/signal-event", "ibay-create", $name) == 0) {
	    $self->success("SUCCESSFULLY_CREATED_IBAY");
        } else {
	    $self->error("ERROR_WHILE_CREATING_IBAY");
        }
    } else {
        $self->error('CANT_CREATE_IBAY');
    }
}

sub modify_ibay {
    my ($self) = @_;
    my $name = $self->cgi->param('name');
    if (my $acct = $accountdb->get($name)) {
        if ($acct->prop('type') eq 'ibay') {
            $acct->merge_props(
                Name         => $self->cgi->param('description'),
                CgiBin       => $self->cgi->param('CgiBin'),
                Group        => $self->cgi->param('group'),
                PublicAccess => $self->cgi->param('publicAccess'),
                UserAccess   => $self->cgi->param('userAccess'),
		Plugin       => $self->cgi->param('Plugin'),
            );

	    # delegate to the IbayPlugin
	    my $pluginName = $self->cgi->param('Plugin');
	    my $ibayPlugin = esmith::IbayPlugin->load($pluginName);
	    $ibayPlugin->ibay_panel_save_fields($self, $acct);

            if (system ("/sbin/e-smith/signal-event", "ibay-modify", $name) == 0) {
		$self->success("SUCCESSFULLY_MODIFIED_IBAY");
            } else {
                $self->error("ERROR_WHILE_MODIFYING_IBAY");
            }
        } else {
            $self->error('CANT_FIND_IBAY');
        }
    } else {
        $self->error('CANT_FIND_IBAY');
    }
}

=for testing
can_ok('main', 'remove_ibay');

=cut

sub remove_ibay {
    my ($self) = @_;
    my $name = $self->cgi->param('name');
    if (my $acct = $accountdb->get($name)) {
        if ($acct->prop('type') eq 'ibay') {
            $acct->set_prop('type', 'ibay-deleted');

            my $domains_db = esmith::DomainsDB->open();
            my @domains = $domains_db->get_all_by_prop(Content=>$name);
            foreach my $d (@domains) {
                $d->set_prop(Content => 'Primary');
            }

            if (system ("/sbin/e-smith/signal-event", "ibay-delete", $name) == 0) {
                $self->success("SUCCESSFULLY_DELETED_IBAY");
		$acct->delete();
            } else {
                $self->error("ERROR_WHILE_DELETING_IBAY");
            }
        } else {
            $self->error('CANT_FIND_IBAY');
        }

    } else {
        $self->error('CANT_FIND_IBAY');
    }
    $self->wherenext('First');
}

=for testing
can_ok('main', 'reset_password');

=cut

sub reset_password {
    my ($self) = @_;
    my $name = $self->cgi->param('name');
    my $newPass = $self->cgi->param('newPass');
    my $acct;
    if (($acct = $accountdb->get($name)) && ($acct->prop('type') eq 'ibay')) {
        esmith::util::setIbayPassword ($acct->key, $newPass);
        $acct->set_prop('PasswordSet', 'yes');
        if (system ("/sbin/e-smith/signal-event", "password-modify", $name) == 0) {
            $self->success("SUCCESSFULLY_RESET_PASSWORD");
        } else {
            $self->error("ERROR_WHILE_RESETTING_PASSWORD");
        }
    } else {
        $self->error('CANT_FIND_IBAY');
    }
    $self->wherenext('First');
}

=pod

=head2 getExtraParams()

Sets variables used in the lexicon to their required values.

=for testing
$panel->{cgi}->param(-name=>'name', -value=>'foo');
my %ret = $panel->getExtraParams();
is($ret{name}, 'foo', ' .. name field is foo');
isnt($ret{description}, undef, ' .. description field isnt undef');

=cut

sub getExtraParams
{
	my $self = shift;
	my $q = $self->{cgi};
	my $name = $q->param('name');
	my $desc = '';

	if ($name)
	{
		my $acct = $accountdb->get($name);
		if ($acct)
		{
			$desc = $acct->prop('Name');
		}
	}
	return (name => $name, description => $desc);

	# delegate to the IbayPlugin
	my $pluginName = $q->param->('Plugin');
	my $ibayPlugin = esmith::IbayPlugin->load($pluginName);

	my %params = (
	    name => $name,
	    description => $desc,
	    $ibayPlugin->get_extra_params($self),
	);
	return %params;
}

=head2 verifyPasswords()

Returns an error message if the two new passwords input don't match.

=cut

sub verifyPasswords {
        my $self = shift;
        my $pass2 = shift;

        my $pass1 = $self->{cgi}->param('newPass');
        unless ($pass1 eq $pass2) {
                $self->{cgi}->param( -name => 'wherenext', -value => 'Password' );
                return "PASSWORD_VERIFY_ERROR";
        }
        return "OK";
}


=head2 validate_name

Checks that the name supplied does not contain any unacceptable chars.
Returns OK on success or a localised error message otherwise.

ting
is($panel->validate_name('foo'), 'OK', 'validate_name');
is($panel->validate_name('cust3.prj12'),'OK',' .. name with dots and nums');
is($panel->validate_name('cust_bay'),'OK',' .. name with underscore');
isnt($panel->validate_name('3amigos'), 'OK', ' .. cannot start with number');
isnt($panel->validate_name('betty ford'), 'OK', ' .. cannot contain space');

=cut

sub validate_name
{
    my ($self, $acctName) = @_;

    unless ($acctName =~ /^([a-z][\_\.\-a-z0-9]*)$/)
    {
        return $self->localise('ACCT_NAME_HAS_INVALID_CHARS',
                             {acctName => $acctName});
    }
    return "OK";
}


=head2 check_password

Validates the password using the desired strength

=cut

sub check_password {
	my $self = shift;
	my $pass1 = shift;

        my $check_type;
        my $rec = $configdb->get('passwordstrength');
        $check_type = ($rec ? ($rec->prop('Ibays') || 'none') : 'none');

        return $self->validate_password($check_type,$pass1);
}

1;

