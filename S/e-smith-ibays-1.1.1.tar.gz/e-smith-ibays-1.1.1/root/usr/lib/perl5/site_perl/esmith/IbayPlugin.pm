package esmith::IbayPlugin;

use strict;
use File::Basename;

sub load
{
    my $class = shift;
    my $name = shift || "none";
    # untaint 
    if ($name =~ /^(.*)$/)
    {
	$name = $1;
    }
    no strict 'refs';
    my $pkg = "esmith::IbayPlugin::${name}";
    eval "use $pkg";
    my $className = $pkg->new;
    return $className;
}

sub list
{
    my @classes = map {basename($_,'.pm')} glob '/etc/e-smith/IbayPlugin/*';
    return @classes;
}

1;
