package esmith::IbayPlugin::none;

use strict;
use File::Find;
use esmith::util;
use esmith::AccountsDB;

# You shouldn't need to override the "new" method
sub new
{
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my %attr;
    bless \%attr, $class;
}

# not sure what to do with this
sub webAccess
{
    my $self = shift;
    my $ibay = $self->{ibay};
    
    # in httpd.conf template, the $localAccess variable holds, ie:
    # 127.0.0.1 192.62.102.0/255.255.255.0
}

# You will need to override the "install" method
# called by ibay-plugin-install action
# copy application files, setup filesystem structure
sub install
{
    my $self = shift;
    my $ibayName = shift;

    #------------------------------------------------------------
    # Create the ibay files and set the password.
    #------------------------------------------------------------

    system("/bin/cp", "-Rp", "/etc/e-smith/skel/ibay/.",
	"/home/e-smith/files/ibays/$ibayName") == 0
	    or die "Error copying ibay skeletal files";

    processTemplate( {
	TEMPLATE_PATH=>"/home/e-smith/files/ibays/html/index.html",
	OUTPUT_FILENAME=>"/home/e-smith/files/ibays/$ibayName/html/index.html",
	MORE_DATA=>{IBAY_NAME=>$ibayName},
		} );

}

# called by ibays panel when creating ibay (ask for extra params)
# called by ibays panel when modifying ibay
sub installCheck
{
    # 
}

# called when you change an ibay from one class to another
# not called by ibay-remove, as it just deletes everything
sub uninstall
{
    #
}

# called by ibays panel when switching ibay plugins
sub uninstallCheck
{
    #
}

# called by ibays panel when upgrading application
sub upgradeCheck
{

}

# called by ibay-plugin-upgrade action
# perform upgrade/migration
sub upgrade
{
    my $self = shift;
    my $ibayName = shift;
}

# called by ibay-plugin-repair action
# perform sanity chown/chmod
sub repair
{
    my $self = shift;
    my $ibayName = shift;

    my $accountsDB = esmith::AccountsDB->open;
    my $ibay = $accountsDB->get($ibayName);
    my %properties = $ibay->props;

    #------------------------------------------------------------
    # Fix permissions on ibay files.
    #------------------------------------------------------------

    #--------------------------------------------------
    # main directory is writeable only by root
    #--------------------------------------------------

    chdir "/home/e-smith/files/ibays/$ibayName"
       or die "Could not chdir to /home/e-smith/files/ibays/$ibayName";

    esmith::util::chownFile("root", "root", ".");
    chmod 0755, ".";

    #--------------------------------------------------
    # fix ownership of subdirectories
    #--------------------------------------------------

    #--------------------------------------------------
    # Set the group as www if it was admin, since 
    # while set as admin, the web server no longer has
    # access to the ibay HTML directory, and web pages.
    #--------------------------------------------------

    our $group = ($properties{'Group'} eq "admin") ? "www" : $properties {'Group'};

    # Make sensible defaults
    our $owner = undef;
    our $fileperm = 0600;
    our $dirperm = 0550;

    if ($properties {'UserAccess'} eq 'wr-admin-rd-group')
    {
	$owner = "admin";
	$fileperm = 0640;
	$dirperm = 02750;
    }
    elsif ($properties {'UserAccess'} eq 'wr-group-rd-group')
    {
	$fileperm = 0660;
	$dirperm = 02770;
    }
    elsif ($properties {'UserAccess'} eq 'wr-group-rd-everyone')
    {
	$fileperm = 0664;
	$dirperm = 02775;
    }
    else
    {
	warn("Value of UserAccess bad or unset");
    }

    sub process
    {
	if (-l)
	{
	    $File::Find::prune = 1;
	}
	else
	{
	    esmith::util::chownFile($owner, $group, $_);
	    if (-d)
	    {
		chmod $dirperm, $_;
	    }
	    elsif (-f)
	    {
		# Preserve execute permissions on files
		my $experm = (stat($_))[2] & 0111;
		$experm |= $fileperm;
		chmod $experm, $_;
	    }
	}
    }

    find(\&process, grep { !/^\.\.?$/ } glob('* .*'));

}

sub ibay_panel_load_fields { 1; }
sub ibay_panel_save_fields { 1; }
sub ibay_panel_load_form_elements { "" }
sub ibay_panel_export_functions { qw() }

sub create_modify_post_event
{
    my $self = shift;
    my $fm = shift;
    $fm->handle_ibays();
}

sub handle_ibays_wherenext { 'First' }

1;
